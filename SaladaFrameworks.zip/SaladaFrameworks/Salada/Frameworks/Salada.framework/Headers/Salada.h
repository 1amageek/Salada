//
//  Salada.h
//  Salada
//
//  Created by 1amageek on 2017/03/05.
//  Copyright © 2017年 Stamp. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Salada.
FOUNDATION_EXPORT double SaladaVersionNumber;

//! Project version string for Salada.
FOUNDATION_EXPORT const unsigned char SaladaVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Salada/PublicHeader.h>


